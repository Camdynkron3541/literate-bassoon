// ============================================================
//  JupiterX | Menu/Buttons.cs
//  Copyright (c) 2026 Jupiterx (@NAuth). All rights reserved.
//
//  This software and its source code are the property of the
//  author. Unauthorized copying, redistribution, modification,
//  or reuse of any part of this project, in whole or in part,
//  without express written permission is strictly prohibited.
//
//  Version: 2.0.0 | By Silent/Ashley/Nova (@s1lnt)
//  Stripped: Photon Bots only
// ============================================================

using JupiterX.Classes.Menu;
using JupiterX.Managers;
using JupiterX.Mods;
using JupiterX.Notifications;
using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using static JupiterX.Menu.Main;
using static JupiterX.Settings;

namespace JupiterX.Menu
{
    public class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main
                new ButtonInfo { buttonText = "Photon Bots", method =() => CurrentCategoryName = "Photon Bots", isTogglable = false, toolTip = "Opens the photon bots page for the menu."},
                new ButtonInfo { buttonText = "Enabled", method =() => CurrentCategoryName = "Enabled", isTogglable = false, toolTip = "Opens the enabled mods page for the menu."},
                new ButtonInfo { buttonText = "Favorite", method =() => CurrentCategoryName = "Favorite", isTogglable = false, toolTip = "Opens the favorite mods page for the menu."},
            },

            new ButtonInfo[] { // Photon Bots | mocas stinky -nova
                new ButtonInfo { buttonText = "Exit Photon Bots", method =() => CurrentCategoryName = "Main", isTogglable = false, toolTip = "Returns to the main page of the menu." },

                new ButtonInfo { buttonText = "Spawn Bots", method =() => PhotonBots.SpawnBots(), isTogglable = false, toolTip = "Spawns photon bots in the current room." },
                new ButtonInfo { buttonText = "Stop Bots", method =() => PhotonBots.StopBots(), isTogglable = false, toolTip = "Stops and clears all photon bots." },

                new ButtonInfo { buttonText = "Bot Count", overlapText = "Bot Count <color=grey>[</color><color=cyan>10</color><color=grey>]</color>", method =() => PhotonBots.IncreaseBotCount(), enableMethod =() => PhotonBots.IncreaseBotCount(), disableMethod =() => PhotonBots.DecreaseBotCount(), incremental = true, isTogglable = false, toolTip = "Changes how many bots to spawn (1-50)." },
                new ButtonInfo { buttonText = "Bot Name", overlapText = "Bot Name <color=grey>[</color><color=cyan>JUPITERX</color><color=grey>]</color>", method =() => PhotonBots.NextBotName(), enableMethod =() => PhotonBots.NextBotName(), disableMethod =() => PhotonBots.PrevBotName(), incremental = true, isTogglable = false, toolTip = "Changes the name prefix for spawned bots." },

                new ButtonInfo { buttonText = "Bring Bots", method =() => PhotonBots.BringBots(), isTogglable = false, toolTip = "Brings all bots to your position." },
                new ButtonInfo { buttonText = "Bots To Gun", method =() => PhotonBots.BotsToGun(), isTogglable = true, toolTip = "Moves bots to wherever your gun points." },

                new ButtonInfo { buttonText = "Freeze Bots", enableMethod =() => PhotonBots.freezeBots = true, disableMethod =() => PhotonBots.freezeBots = false, isTogglable = true, toolTip = "Freezes all bots in place." },

                new ButtonInfo { buttonText = "Orbit Me", method =() => PhotonBots.OrbitMe(), isTogglable = true, toolTip = "Makes bots orbit around you." },
                new ButtonInfo { buttonText = "Orbit Gun", method =() => PhotonBots.OrbitGun(), isTogglable = true, toolTip = "Makes bots orbit around whoever you shoot." },
                new ButtonInfo { buttonText = "Stack Bots", method =() => PhotonBots.StackBots(), isTogglable = true, toolTip = "Stacks bots on top of each other." },
                new ButtonInfo { buttonText = "Line Bots", method =() => PhotonBots.LineBots(), isTogglable = true, toolTip = "Arranges bots in a line." },
                new ButtonInfo { buttonText = "Spaz Bots", method =() => PhotonBots.SpazBots(), isTogglable = true, toolTip = "Makes bots spaz out randomly." },
                new ButtonInfo { buttonText = "Stop Movement", method =() => PhotonBots.StopMovement(), isTogglable = false, toolTip = "Stops all bot movement." },

                new ButtonInfo { buttonText = "Orbit Radius", overlapText = "Orbit Radius <color=grey>[</color><color=cyan>3.5</color><color=grey>]</color>", method =() => PhotonBots.RadiusUp(), enableMethod =() => PhotonBots.RadiusUp(), disableMethod =() => PhotonBots.RadiusDown(), incremental = true, isTogglable = false, toolTip = "Changes the orbit radius (1-15)." },
                new ButtonInfo { buttonText = "Orbit Speed", overlapText = "Orbit Speed <color=grey>[</color><color=cyan>60</color><color=grey>]</color>", method =() => PhotonBots.SpeedUp(), enableMethod =() => PhotonBots.SpeedUp(), disableMethod =() => PhotonBots.SpeedDown(), incremental = true, isTogglable = false, toolTip = "Changes the orbit speed (0-180)." },

                new ButtonInfo { buttonText = "Mirror Me", method =() => PhotonBots.MirrorMe(), isTogglable = true, toolTip = "Bots copy your movements." },
                new ButtonInfo { buttonText = "Mirror Gun", method =() => PhotonBots.MirrorGun(), isTogglable = true, toolTip = "Bots copy the movements of whoever you shoot." },

                new ButtonInfo { buttonText = "Bot Taps", enableMethod =() => PhotonBots.botTaps = true, disableMethod =() => PhotonBots.botTaps = false, isTogglable = true, toolTip = "Makes bots spam hand taps." },
                new ButtonInfo { buttonText = "Tap Sound", overlapText = "Tap Sound <color=grey>[</color><color=cyan>0</color><color=grey>]</color>", method =() => PhotonBots.NextTapSound(), enableMethod =() => PhotonBots.NextTapSound(), disableMethod =() => PhotonBots.PrevTapSound(), incremental = true, isTogglable = false, toolTip = "Changes the tap sound ID (0-61)." },
                new ButtonInfo { buttonText = "Bot Colors", enableMethod =() => PhotonBots.botColors = true, disableMethod =() => PhotonBots.botColors = false, isTogglable = true, toolTip = "Makes bots cycle through rainbow colors." },

                new ButtonInfo { buttonText = "Bot Event Spam", enableMethod =() => PhotonBots.botEventSpam = true, disableMethod =() => PhotonBots.botEventSpam = false, isTogglable = true, toolTip = "Makes bots spam junk events." },
                new ButtonInfo { buttonText = "Bot Prefab Spam", enableMethod =() => PhotonBots.botPrefabSpam = true, disableMethod =() => PhotonBots.botPrefabSpam = false, isTogglable = true, toolTip = "Makes bots spam prefabs." },
                new ButtonInfo { buttonText = "Bot Crash", enableMethod =() => PhotonBots.botCrash = true, disableMethod =() => PhotonBots.botCrash = false, isTogglable = true, toolTip = "Makes bots send crash events." },
            },

            new ButtonInfo[] { }, // Temporary Category

            new ButtonInfo[] { // Enabled
                new ButtonInfo { buttonText = "Exit Enabled", method =() => CurrentCategoryName = "Main", isTogglable = false, toolTip = "Returns to the main page of the menu." },
            },

            new ButtonInfo[] { // Favorites
                new ButtonInfo { buttonText = "Exit Favorite", method =() => CurrentCategoryName = "Main", isTogglable = false, toolTip = "Returns to the main page of the menu." },
            },

            new [] // Internal
            {
                new ButtonInfo { buttonText = "Search", method = KeyboardManager.Search, isTogglable = false, toolTip = "Lets you search for specific mods."},
                new ButtonInfo { buttonText = "Global Return", method = Settings.GlobalReturn, isTogglable = false, toolTip = "Returns you to the previous category." },
                new ButtonInfo { buttonText = "Accept Prompt", method =() => { NotificationManager.ClearAllNotifications(); CurrentPrompt.AcceptAction?.Invoke(); Utility.StopCurrentPrompt(); }, isTogglable = false },
                new ButtonInfo { buttonText = "Decline Prompt", method =() => { NotificationManager.ClearAllNotifications(); CurrentPrompt.DeclineAction?.Invoke(); Utility.StopCurrentPrompt(); }, isTogglable = false },
            },

            // Stubs so leftover manager code does not index -1
            new ButtonInfo[] { new ButtonInfo { buttonText = "Exit", method =() => CurrentCategoryName = "Main", isTogglable = false } }, // Achievements
            new ButtonInfo[] { new ButtonInfo { buttonText = "Exit", method =() => CurrentCategoryName = "Main", isTogglable = false } }, // Plugin Settings
            new ButtonInfo[] { new ButtonInfo { buttonText = "Exit", method =() => CurrentCategoryName = "Main", isTogglable = false } }, // Players
            new ButtonInfo[] { new ButtonInfo { buttonText = "Exit", method =() => CurrentCategoryName = "Main", isTogglable = false } }, // Soundboard
            new ButtonInfo[] { new ButtonInfo { buttonText = "Exit", method =() => CurrentCategoryName = "Main", isTogglable = false } }, // Settings
        };

        public static string[] categoryNames =
        {
            "Main",
            "Photon Bots",
            "Temporary Category",
            "Enabled",
            "Favorite",
            "Internal",
            "Achievements",
            "Plugin Settings",
            "Players",
            "Soundboard",
            "Settings",
        };

        public static int _currentCategoryIndex;
        public static event Action OnCategoryChanged;

        public static int CurrentCategoryIndex
        {
            get => _currentCategoryIndex;
            set
            {
                _currentCategoryIndex = value;
                pageNumber = 0;

                OnCategoryChanged?.Invoke();
            }
        }

        public static string CurrentCategoryName
        {
            get => Buttons.categoryNames[CurrentCategoryIndex];
            set =>
                CurrentCategoryIndex = Buttons.GetCategory(value);
        }

        private static readonly Dictionary<string, (int Category, int Index)> cacheGetIndex = new Dictionary<string, (int Category, int Index)>(); // Looping through 800 elements is not a light task :/

        public static ButtonInfo GetIndex(string buttonText)
        {
            if (buttonText == null)
                return null;

            if (cacheGetIndex.TryGetValue(buttonText, out var cacheData))
            {
                try
                {
                    if (buttons[cacheData.Category][cacheData.Index].buttonText == buttonText)
                        return buttons[cacheData.Category][cacheData.Index];
                }
                catch { cacheGetIndex.Remove(buttonText); }
            }

            int categoryIndex = 0;
            foreach (ButtonInfo[] buttons in buttons)
            {
                int buttonIndex = 0;
                foreach (ButtonInfo button in buttons)
                {
                    if (button.buttonText == buttonText)
                    {
                        try
                        {
                            cacheGetIndex.Add(buttonText, (categoryIndex, buttonIndex));
                        }
                        catch
                        {
                            cacheGetIndex.Remove(buttonText);
                        }

                        return button;
                    }
                    buttonIndex++;
                }
                categoryIndex++;
            }

            return null;
        }
        public static int GetCategory(string categoryName) =>
            categoryNames.ToList().IndexOf(categoryName);

        public static int AddCategory(string categoryName)
        {
            List<ButtonInfo[]> buttonInfoList = buttons.ToList();
            buttonInfoList.Add(new ButtonInfo[] { });
            buttons = buttonInfoList.ToArray();

            List<string> categoryList = categoryNames.ToList();
            categoryList.Add(categoryName);
            categoryNames = categoryList.ToArray();

            return buttons.Length - 1;
        }
        public static void RemoveCategory(string categoryName)
        {
            List<ButtonInfo[]> buttonInfoList = buttons.ToList();
            buttonInfoList.RemoveAt(GetCategory(categoryName));
            buttons = buttonInfoList.ToArray();

            List<string> categoryList = categoryNames.ToList();
            categoryList.Remove(categoryName);
            categoryNames = categoryList.ToArray();
        }
        public static void AddButton(int category, ButtonInfo button, int index = -1)
        {
            List<ButtonInfo> buttonInfoList = buttons[category].ToList();
            if (index > 0)
                buttonInfoList.Insert(index, button);
            else
                buttonInfoList.Add(button);

            buttons[category] = buttonInfoList.ToArray();
        }
        public static void AddButtons(int category, ButtonInfo[] buttons, int index = -1)
        {
            List<ButtonInfo> buttonInfoList = Buttons.buttons[category].ToList();
            if (index > 0)
            {
                for (int i = 0; i < buttons.Length; i++)
                    buttonInfoList.Insert(index + i, buttons[i]);
            }
            else
                buttonInfoList.AddRange(buttons);

            Buttons.buttons[category] = buttonInfoList.ToArray();
        }
        public static void RemoveButton(int category, string name, int index = -1)
        {
            List<ButtonInfo> buttonInfoList = buttons[category].ToList();
            if (index > 0)
                buttonInfoList.RemoveAt(index);
            else
            {
                foreach (var button in buttonInfoList.Where(button => button.buttonText == name))
                {
                    buttonInfoList.Remove(button);
                    break;
                }
            }

            buttons[category] = buttonInfoList.ToArray();
        }
    }
}
