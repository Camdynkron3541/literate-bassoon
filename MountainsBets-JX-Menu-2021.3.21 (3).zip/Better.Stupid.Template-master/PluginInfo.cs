namespace StupidTemplate
{
    public class PluginInfo
    {
        public const string GUID = "org.jxmodding.mountainbets.menu";
        public const string Name = "Mountains Bets"; // menu title
        public const string Description = "JX MODDING GAME PCVR — Mountains Bets menu";
        public const string Version = "1.0.0";
    }
}
